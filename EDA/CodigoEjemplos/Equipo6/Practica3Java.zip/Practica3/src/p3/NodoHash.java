/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p3;

/**
 *
 * @author Mariel, Diana, Yuliana
 */
public class NodoHash<T> {
    T elem;
    NodoHash<T> sig;
    
    
    //elem: cualquier tipo de dato, en este caso son titulos
    //sig: el siguiente nodo hash
    public NodoHash(T elem){
        this.elem = elem;
        this.sig = null;
    }
    
    public T getElem(){
        return this.elem;
    }
    
    public void setElem(T elem){
       this.elem=elem;
    }
    
    public NodoHash<T> getSig(){
        return this.sig;
    }
    
    public void setSig(NodoHash<T> siguiente){
        this.sig = siguiente;
    }
    //getKey?
    
}
