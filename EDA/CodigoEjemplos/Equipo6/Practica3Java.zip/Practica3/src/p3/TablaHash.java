package p3;

/**
 *
 * @author Mariel, Diana, Yuliana
 */
public class TablaHash<T> {
    int cant = 0;
    NodoHash[] tabla;
    
    //Se crea una tabla según el tamaño que se indica y en cada casilla se guarda un nodo hash vacío que 
    //será la cabeza de las listas que se guardarán en la tabla para manejar la coliciones
    public TablaHash(int tamano){
        tabla = new NodoHash[tamano];
    }
    
    public NodoHash[] getTabla(){
        return tabla;
    }
    
    //Inserción del elemento a la tabla, usando la función de hash según multiplicación
    public void inserta(T elem, int llave){
        NodoHash n = new NodoHash(elem);
        //donde debería de ir el elemento en la tabla
        int pos = funcHashMult(llave) % tabla.length;
        NodoHash aux = tabla[pos];
        if(aux==null){
            tabla[pos]=n;
            cant++;
        } else {
            while(aux.getSig()!=null){
            aux = aux.getSig();
        }
            if(aux.getSig()==null){
                aux.setSig(n);
                cant++;
            }
        }
        
    }
    
    //insercion segun division
    public void insertaD(T elem, int llave){
        NodoHash n = new NodoHash(elem);
        
        //donde debería de ir el elemento en la tabla
        int pos = funcHashDiv(llave) % tabla.length;
        NodoHash aux = tabla[pos];
        if(aux==null){
            tabla[pos]=n;
            cant++;
        } else {
            while(aux.getSig()!=null){
            aux = aux.getSig();
        }
            if(aux.getSig()==null){
                aux.setSig(n);
                cant++;
            }
        }
    }
    
    public boolean busca(T elem, int llave){
        //Se crea un nodo auxiliar con el elemento que se desea buscar para poder extraer el valor de hash 
        //y encontrar la posición donde debería de estar el elemento.
        boolean res = false;
        
        //Se obtiene la posición
        int pos = funcHashMult(llave) % tabla.length;
        
        //Se busca el elemento en la lista almacenada en la casilla indicada por la funcion hash
        NodoHash actual = tabla[pos].getSig();
        while(!res && actual != null){
            if(actual.getElem() == elem)
                res = true;
            actual = actual.getSig();
        }
        return res;
    }
    
    //Para buscar un elemento en específico en la tabla según division
    public boolean buscaD(T elem, int llave){
        //Se crea un nodo auxiliar con el elemento que se desea buscar para poder extraer el valor de hash 
        //y encontrar la posición donde debería de estar el elemento.
        boolean res = false;
        
        //Se obtiene la posición
        int pos = funcHashDiv(llave) % tabla.length;
        
        //Se busca el elemento en la lista almacenada en la casilla indicada por la funcion hash
        NodoHash actual = tabla[pos].getSig();
        while(!res && actual != null){
            if(actual.getElem() == elem)
                res = true;
            actual = actual.getSig();
        }
        return res;
    }
    
    //Para borrar un elemento de la tabla hash
    public boolean borra(T elem, int llave){
        boolean res = false;
        //Se obtiene la posición en donde debería de estar el elemento según la 
        //función hash
        int pos = funcHashMult(llave) % tabla.length;
        NodoHash prev = tabla[pos];
        
        //Nos poscisionamos en la cabeza de la lista
        NodoHash actual = prev.getSig();
        
        //Buscamos la lista mientras que esta no se acabe y mientras que no se encuentre el elemento que se quiere borrar
        while(actual != null && actual.getElem() != elem){
            prev = actual;
            actual = actual.getSig();
        }
        
        NodoHash aux;
        //cuando se sale del while porque se encontró un nodo igual al que se buscaba borrar, se redirigen los atributos de sig
        //del nodo anterior para 'borrar' el actual
        if(actual != null && actual.getElem()==elem){
            aux = actual.getSig();
            prev.setSig(aux);
            cant -= 1;
            res = true;
        }
        
        return res;
    }
    
    public boolean borraD(T elem, int llave){
        boolean res = false;
        //Se obtiene la posición en donde debería de estar el elemento según la 
        //función hash
        int pos = funcHashDiv(llave) % tabla.length;
        NodoHash prev = tabla[pos];
        
        //Nos poscisionamos en la cabeza de la lista
        NodoHash actual = prev.getSig();
        
        //Buscamos la lista mientras que esta no se acabe y mientras que no se encuentre el elemento que se quiere borrar
        while(actual != null && actual.getElem() != elem){
            prev = actual;
            actual = actual.getSig();
        }
        
        NodoHash aux;
        //cuando se sale del while porque se encontró un nodo igual al que se buscaba borrar, se redirigen los atributos de sig
        //del nodo anterior para 'borrar' el actual
        if(actual != null && actual.getElem()==elem){
            aux = actual.getSig();
            prev.setSig(aux);
            cant -= 1;
            res = true;
        }
        
        return res;
    }
    
    //Funcion de Hash por division
    public int funcHashDiv(int llave){
        int res = llave % tabla.length;
        return res;
    }
    
    //funcion de Hash por multiplicacion
    public int funcHashMult(int llave){
        int aux = (int)(1/((1+Math.sqrt(5))/2));
        return aux;
    }
    
    //Regresa la cantidad de datos de una casilla en concreto
    public int[] numDatosXCasilla(){
        int[] res = new int[tabla.length];
        for(int i=0; i<res.length; i++){
            int cont = 0;
            NodoHash actual = tabla[i];
            if(actual!=null){
                actual.getSig();
                while(actual != null){
                cont += 1;
                actual = actual.getSig();
            }
            }
            
            res[i] = cont;
        }
        return res;
    }
    
    public double promDatosXCasilla(){
        int res = 0;
        int[] cant = numDatosXCasilla();
        for(int i=0; i<cant.length; i++){
            res += cant[i];
        }
        return res/cant.length;
    }
    
    public int numcasillasVacias(){
        int cont = 0;
        for(int i=0; i<tabla.length; i++){
            NodoHash actual = tabla[i];
            
            if(actual==null){
                cont+=1;
            }
        }
        return cont;
    }
    
    public void toStr(){
        for(int i=0; i<tabla.length; i++){
            NodoHash actual = tabla[i].getSig();
            System.out.println("Casilla "+i);
            while(actual!=null){
                System.out.println(actual.getElem());
                actual = actual.getSig();
            }
        }
    }
    
}
