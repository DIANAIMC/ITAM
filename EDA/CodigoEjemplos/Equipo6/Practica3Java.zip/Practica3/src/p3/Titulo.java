package p3;
/**
 *
 * @author Mariel, Diana, Yuliana
 */
public class Titulo {
  int id;
  String tipo;
  String titulo;
  String directorx;
  String reparto;
  String pais;
  String fechaN; //Fecha en que se agregó a Netflix
  String fechaE; //Fecha de estreno
  String calificacion;
  String duracion; //en minutos
  String categoria; //en cuál está listada en netflix
  String descripcion;

  public Titulo(int id, String tipo, String t, String dir, String cast, String p, String fN, String fE, String r, String d, String cat, String desc) {
    this.id = id;
    this.tipo = tipo;
    this.titulo = t;
    this.directorx = dir;
    this.reparto = cast;
    this.pais = p;
    this.fechaN = fN;
    this.fechaE = fE;
    this.calificacion = r;
    this.duracion = d;
    this.categoria = cat;
    this.descripcion = desc;
  }

  public String getTitulo(){
    return titulo;
  }
  
  //El valor clave asociado a los objetos titulos
  public int getKey(){
    return id;
  }
  
  public boolean compareTo(int otro){
      return this.id < otro;
  } 
  
  public String toString(){
    return "Id: "+id+"\nTipo: "+tipo+"\nTitulo: "+titulo+"\nDirectorx: "+directorx+"\nCast: "+reparto+"\nPais: "+pais+"\nFecha Netflix: "+fechaN+"\nFecha Estreno: "+fechaE+"\nCalificacion: "+calificacion+"\nDuración: "+duracion+"\nCategoria: "+categoria+"\nDescripcion: "+descripcion;
  }

}
