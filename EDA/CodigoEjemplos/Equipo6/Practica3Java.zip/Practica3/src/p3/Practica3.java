package p3;
import java.io.File;
import java.io.FileNotFoundException;
import static java.lang.System.currentTimeMillis;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Mariel, Diana, Yuliana
 */
public class Practica3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
//      pruebaComparacion(100, 100, 8000,lecturaArchivo());
//      pruebaComparacion(1000, 1000, 8000,lecturaArchivo());
//      pruebaComparacion(5000, 5000, 8000,lecturaArchivo());
//      pruebaComparacion(100, 1000, 8000,lecturaArchivo());
//      pruebaComparacion(1000, 5000, 8000,lecturaArchivo());
//      pruebaComparacion(5000, 8000, 8000,lecturaArchivo());
//      pruebaComparacion(1000, 100, 8000,lecturaArchivo());
//      pruebaComparacion(5000, 1000, 8000,lecturaArchivo());
//      pruebaComparacion(8000, 5000, 8000,lecturaArchivo());
      
      
//      pruebasDatos(100, 100, lecturaArchivo());
//      pruebasDatos(1000, 1000, lecturaArchivo());
//      pruebasDatos(5000, 5000, lecturaArchivo());
//      pruebasDatos(100, 1000, lecturaArchivo());
//      pruebasDatos(1000, 5000, lecturaArchivo());
//      pruebasDatos(5000, 8000, lecturaArchivo());
//      pruebasDatos(1000, 100, lecturaArchivo());
//      pruebasDatos(5000, 1000, lecturaArchivo());
//      pruebasDatos(8000, 5000, lecturaArchivo());
//      

    }
    
    public static ArrayList<Titulo> lecturaArchivo(){
      try {
        File myObj = new File("titulosNetflix.txt");
        Scanner lector = new Scanner(myObj);
        ArrayList<Titulo> l = new ArrayList<Titulo>();
        for(int i=0; i<8008; i++){
          String data = lector.nextLine();
          String[] d = data.split("/", 12);
          Titulo t = new Titulo(Integer.parseInt(d[0]),d[1],d[2],d[3],d[4],d[5],d[6],d[7],d[8],d[9],d[10],d[11]);
          l.add(t);
        }
      lector.close();
      return l;
      } catch (FileNotFoundException e) {
          System.out.println("Error.");
          e.printStackTrace();
          return null;
        }
    }
    //Métodos de prueba
    
    
    //﻿Método de prueba relacionado al análisis de la cantidad de datos almacenados en cada casilla 
    //de la tabla, el número de ellas que están vacías y el promedio de la cantidad de datos que hay en las listas.
    public static void pruebasDatos(int n, int m, ArrayList<Titulo> listaTitulos){
        //﻿Creación de una lista de n películas, sea n dado como parámetro
        ArrayList<Titulo> t = new ArrayList<Titulo>();
        for(int j=0; j<n;j++){
                t.add(listaTitulos.get(j));
        }
        
        //Creación de una tabla de hash con tamaño m, sea m dado como parámetro
        TablaHash tabla = new TablaHash(m);
        
        //Se insertan las n peliculas en la tabla de hash
        for(int i=0; i<n; i++)
            tabla.insertaD(t.get(i), t.get(i).getKey());
        
        int[] datosXCasilla = tabla.numDatosXCasilla();
        int numVacias = tabla.numcasillasVacias();
        double promDatos = tabla.promDatosXCasilla();
        
        for(int i=0; i<datosXCasilla.length; i++){
            System.out.println("Hay "+datosXCasilla[i]+" datos en la casilla "+i+" de la tabla");
        }
        System.out.println();
        System.out.println("Hay "+numVacias+" casillas vacias en la tabla.");
        System.out.println("El promedio de datos por casilla es: "+promDatos);
        
        tabla.toStr();
    }
    
    //﻿Método de prueba relacionado a la comparación del desempeño de la inserción con dos diferentes métodos de 
    //hash: el método de la división y el de la multiplicación. En esta prueba se obtienen los datos necesarios para el
    //análisis de la cantidad de datos almacenados en cada casilla de la tabla, el número de ellas que están 
    //vacías y el promedio de la cantidad de datos que hay en las listas después de haber la inserción correspondiente.
//    public static void pruebaComparacion(int n, int m, double tope, ArrayList<Titulo> listaTitulos){
//        double tiemp;
//         //﻿Creación de una lista de n películas, sea n dado como parámetro
//        ArrayList<Titulo> t = new ArrayList<Titulo>();
//        for(int j=0; j<n;j++){
//                t.add(listaTitulos.get(j));
//        }
//        
//        //﻿ Se crean dos tablas de hash de tamaño m (dada como parámetro) para realizar los 
//        //dos diferentes tipos de inserción.
//        TablaHash t1 = new TablaHash(m); //metodo division
//        TablaHash t2 = new TablaHash(m); //metodo multiplicacion
//        
//        ArrayList<Double> insDiv = new ArrayList<Double>();
//        ArrayList<Double> insMult = new ArrayList<Double>();
//        
//        //Para t1
//        double tiempoInicio = currentTimeMillis();
//        for(int i=0; i<n; i++)
//            t1.insertaD(t.get(i), t.get(i).getKey());
//        for(int i=0; i<n;i++){
//            double tiempoFin = currentTimeMillis();
//            double tiempo = tiempoFin - tiempoInicio;
//            double p = tiempo;
//            if(p>tope)
//                tiemp = tope;
//            else
//                tiemp = p;
//            insDiv.add(tiemp);
//        }
//        
//        //Para t2
//        tiempoInicio = currentTimeMillis();
//        for(int i=0; i<n; i++)
//            t2.inserta(t.get(i), t.get(i).getKey());
//        for(int i=0;i<n;i++){
//            double tiempoFin = currentTimeMillis();
//            double tiempo = tiempoFin - tiempoInicio;
//            double p = tiempo;
//            if(p>tope)
//                tiemp = tope;
//            else
//                tiemp = p;
//            insMult.add(tiemp);
//        }
//        
//        int[] datosDiv = t1.numDatosXCasilla();
//        int[] datosMult = t2.numDatosXCasilla();
//        int numVaciasDiv = t1.numcasillasVacias();
//        int numVaciasMult = t2.numcasillasVacias();
//        double promDatosDiv = t1.promDatosXCasilla();
//        double promDatosMult = t2.promDatosXCasilla();
//        for(int i=0; i<datosDiv.length; i++){
//            System.out.println("Hay "+datosDiv[i]+" datos en la casilla "+i+" de la tabla según división");
//        }
//        System.out.println();
//        for(int i=0; i<datosMult.length; i++){
//            System.out.println("Hay "+datosMult[i]+" datos en la casilla "+i+" de la tabla según multiplicación");
//        }
//        System.out.println();
//        System.out.println("Hay "+numVaciasDiv+" casillas vacias en la tabla según división.");
//        System.out.println();
//        System.out.println("Hay "+numVaciasMult+" casillas vacias en la tabla según multiplicación.");
//        System.out.println();
//        System.out.println("El promedio de datos en la tabla según división por casilla es: "+promDatosDiv);
//        System.out.println();
//        System.out.println("El promedio de datos en la tabla según multiplicación por casilla es: "+promDatosMult);
//        
//        
//        double ins = 0;
//        double bus = 0;
//        double borr = 0;
//        
//        //El cálculo de tiempo se va a hacer 20 veces según multiplicación
//            double[] promIns = new double[20];
//            double[] promBus = new double[20];
//            double[] promBorr = new double[20];
//            for(int j=0; j<20; j++){
//                //Se hace una primera medición del valor de tiempo antes de 
//                //procesar los n datos del tamaño de entrada propia de la vuelta
//                tiempoInicio = currentTimeMillis();
//                //Se hace una segunda medición del valor de tiempo después de procesar los n datos
//                for(int k=0; k<t.size(); k++)
//                    t1.inserta(t.get(k), t.get(k).getKey());
//                double tiempoFin = currentTimeMillis();
//                //Se calcula el tiempo tomado del proceso
//                double tiempo = tiempoFin - tiempoInicio;
//                //Se inserta el tiempo en la lista de promedios particulares.
//                promIns[j] = tiempo;
//            
//                //Este procedimiento se hace para los tres procesos considerados:
//                //insertar, buscar, borrar un dato
//                tiempoInicio = currentTimeMillis();
//                for(int k=0; k<t.size(); k++)
//                    t1.busca(t.get(k), t.get(k).getKey());
//                tiempoFin = currentTimeMillis();
//                tiempo = tiempoFin - tiempoInicio;
//                promBus[j] = tiempo;
//                
//                tiempoInicio = currentTimeMillis();
//                for(int k=0; k<t.size(); k++)
//                    t1.borra(t.get(k), t.get(k).getKey());
//                tiempoFin = currentTimeMillis();
//                tiempo = tiempoFin - tiempoInicio;
//                promBorr[j] = tiempo;
//            }
//            
//            //Se obtiene el promedio de cada una
//            for(int j=0; j<20; j++){
//                ins += promIns[j];
//                bus += promBus[j];
//                borr += promBorr[j];
//            }
//            
//            ins = ins / 20;
//            bus = bus/20;
//            borr = borr/20;
//        
//            System.out.println("Para insertar según multiplicación toma: "+ins);
//            System.out.println("Para buscar según multiplicación toma: "+bus);
//            System.out.println("Para borrar según multiplicación toma: "+borr);
//            System.out.println();
//            
//            ins = 0;
//        bus = 0;
//       borr = 0;
//        
//        //El cálculo de tiempo se va a hacer 20 veces según multiplicación
//           promIns = new double[20];
//            promBus = new double[20];
//            promBorr = new double[20];
//            for(int j=0; j<20; j++){
//                //Se hace una primera medición del valor de tiempo antes de 
//                //procesar los n datos del tamaño de entrada propia de la vuelta
//                tiempoInicio = currentTimeMillis();
//                //Se hace una segunda medición del valor de tiempo después de procesar los n datos
//                for(int k=0; k<t.size(); k++)
//                    t1.insertaD(t.get(k), t.get(k).getKey());
//                double tiempoFin = currentTimeMillis();
//                //Se calcula el tiempo tomado del proceso
//                double tiempo = tiempoFin - tiempoInicio;
//                //Se inserta el tiempo en la lista de promedios particulares.
//                promIns[j] = tiempo;
//            
//                //Este procedimiento se hace para los tres procesos considerados:
//                //insertar, buscar, borrar un dato
//                tiempoInicio = currentTimeMillis();
//                for(int k=0; k<t.size(); k++)
//                    t1.buscaD(t.get(k), t.get(k).getKey());
//                tiempoFin = currentTimeMillis();
//                tiempo = tiempoFin - tiempoInicio;
//                promBus[j] = tiempo;
//                
//                tiempoInicio = currentTimeMillis();
//                for(int k=0; k<t.size(); k++)
//                    t1.borraD(t.get(k), t.get(k).getKey());
//                tiempoFin = currentTimeMillis();
//                tiempo = tiempoFin - tiempoInicio;
//                promBorr[j] = tiempo;
//            }
//            
//            //Se obtiene el promedio de cada una
//            for(int j=0; j<20; j++){
//                ins += promIns[j];
//                bus += promBus[j];
//                borr += promBorr[j];
//            }
//            
//            ins = ins / 20;
//            bus = bus/20;
//            borr = borr/20;
//        
//            System.out.println("Para insertar según división toma: "+ins);
//            System.out.println("Para buscar según división toma: "+bus);
//            System.out.println("Para borrar según división toma: "+borr);
//            
//    }
    
}
